---
title: REST description
---

<!--
SPDX-FileCopyrightText: 2016 Mathieu Stefani
SPDX-FileCopyrightText: 2021 Andrea Pappacoda

SPDX-License-Identifier: Apache-2.0
-->

Documentation writing for this part is still in progress, please refer to the [rest_description](https://github.com/pistacheio/pistache/blob/master/examples/rest_description.cc) example.
