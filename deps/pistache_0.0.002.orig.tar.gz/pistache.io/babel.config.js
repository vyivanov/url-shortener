// SPDX-FileCopyrightText: 2021 Andrea Pappacoda
//
// SPDX-License-Identifier: Apache-2.0

module.exports = {
  presets: [require.resolve('@docusaurus/core/lib/babel/preset')],
};
